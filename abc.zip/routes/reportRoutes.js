const express = require('express');
const router = express.Router();
const Report = require('../models/Report');

// GET /api/reports - Fetch all reports
router.get('/', async (req, res) => {
  try {
    const reports = await Report.find().sort({ createdAt: -1 });
    res.json(reports);
  } catch (err) {
    res.status(500).json({ message: 'Server error fetching reports', error: err.message });
  }
});

// POST /api/reports - Create a new report
router.post('/', async (req, res) => {
  try {
    const { category, description, imageUrl, location } = req.body;

    if (!location || location.lat == null || location.lng == null) {
      return res.status(400).json({ message: 'Location (lat and lng) is required.' });
    }

    const newReport = new Report({
      category,
      description,
      imageUrl: imageUrl || '',
      location,
    });

    const savedReport = await newReport.save();
    res.status(201).json(savedReport);
  } catch (err) {
    res.status(400).json({ message: 'Error creating report', error: err.message });
  }
});

module.exports = router;